import {GameUI} from "../ui/GameUI";

export default function App() {
  return <GameUI />;
}