import * as Mark from '../model/Mark';

export interface WinnerInfo {
   winner: Mark.Mark;
   winnerLine: number[];
}